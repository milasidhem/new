package com.example.myapplication.outils;

import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class MesOutils {
    /**
     * conversion chaine sous format Mon Mar 02 19:56:40 GMT+01:00 2020 (EEE MMM dd hh:mm:ss 'GMT+01:00' YYYY) vers date
     * @param uneDate
     * @return
     */
    public static Date convertStringToDate(String uneDate){
        return convertStringToDate(uneDate,"EEE MMM dd hh:mm:ss 'GMT+01:00' YYYY");
    }

    /**
     * converssion chaine sous format reçu en parametre vers date
     * @param uneDate
     * @param formatAttendu
     * @return
     */
    public static Date convertStringToDate(String uneDate, String formatAttendu){
        SimpleDateFormat formatter = new SimpleDateFormat(formatAttendu);
        try {
            Date date = formatter.parse(uneDate);
            return date;
        } catch (ParseException e) {
            Log.d("ERREUR", "parse de la date impossible "+e.toString());
        }
        return null;
    }

    /**
     * conversion d'une date en chain sous la forme yyyy-MM-dd hh:mm:ss
     * @param uneDate
     * @return
     */
    public static String convertDateToString(Date uneDate){
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return date.format(uneDate);
    }



    /**
     * return un float au format string avec un chiffre apres la virgule
     * @param valeur
     * @return
     */
}
