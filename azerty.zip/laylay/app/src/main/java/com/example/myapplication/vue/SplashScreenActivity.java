package com.example.myapplication.vue;
import android.graphics.Color;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;


import com.example.testprojet.R;

import gr.net.maroulis.library.EasySplashScreen;


public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EasySplashScreen config = new EasySplashScreen(SplashScreenActivity.this).withFullScreen().withTargetActivity(Login.class)
                .withSplashTimeOut(500).withBackgroundColor(Color.parseColor("#1a1b29")).withAfterLogoText("MadinaTec").withLogo(R.mipmap.ic_launcher_mine);
        config.getAfterLogoTextView().setTextColor(Color.WHITE);
        View easySplashScreen = config.create();
        setContentView(easySplashScreen);
    }
}
