package com.example.myapplication.vue;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.myapplication.outils.MesOutils;
import com.example.testprojet.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ReportListAdapter extends BaseAdapter {
    private ArrayList<Report> mesRapports;
    private LayoutInflater inflater;
    private Controle controle;
    private Context contexte;
    private String username;

    public ReportListAdapter(Context contexte,ArrayList<Report> mesRapports, String username){
        this.mesRapports = mesRapports;
        this.contexte = contexte;
        this.inflater = LayoutInflater.from(contexte);
        this.controle = Controle.getInstance(null);
        this.username = username;
    }

    /**
     * retourne le nombre de lignes
     * @return
     */
    @Override
    public int getCount() {
        return mesRapports.size();
    }

    /**
     * retourne l'item de la ligne actuelle
     * @param position
     * @return
     */
    @Override
    public Object getItem(int position) {
        return mesRapports.get(position);
    }

    /**
     * retourne un indice par rapport à la ligne actuelle
     * @param position
     * @return
     */
    @Override
    public long getItemId(int position) {
        return position;
    }


    public Bitmap StringToBitMap(String encodedString) {
        try {
            byte[] encodeByte = Base64.decode(encodedString, Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
            return bitmap;
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
    }


    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder;
        if(view == null){
            holder = new ViewHolder();
            // la ligne est construite avec un formatage (inflater) relié à layout_liste_histo
            view = inflater.inflate(R.layout.layout_list_report,null);
            // chaque propriété du holder est relié à une propriété graphique
            holder.usernametxt = view.findViewById(R.id.usernametxt);
            holder.titletxt = view.findViewById(R.id.titletxt);
            holder.datetxt = view.findViewById(R.id.datetxt);
            holder.imagereport = view.findViewById(R.id.imagereport);
            // affecter le holder à la vue
            view.setTag(holder);
        }
        else{
            //recuperation du holder dans la ligne existance
            holder = (ViewHolder) view.getTag();
        }
        // valorisation du contenu du holder (donc de la ligne)
        holder.datetxt.setText(MesOutils.convertDateToString(mesRapports.get(position).getDate1()));
        holder.titletxt.setText(mesRapports.get(position).getTitle());
        holder.usernametxt.setText(username);
        if(mesRapports.get(position).getImage()!=null)
        Picasso.get().load(mesRapports.get(position).getImage()).resize(500,500).into(holder.imagereport);
        holder.btnListSuppr = view.findViewById(R.id.btnListSuppr);
        holder.btnListSuppr.setTag(position);
        // clic sur le X pour supprimer la ligne existance
        holder.btnListSuppr.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                int position = (int)v.getTag();
                // demande de suppression au controleur
                //controle.delReport(report);
                controle.mesRapports.clear();
                controle.all();
                controle.delReport(mesRapports.get(position));
                // Intent i =
                // raffraichir la liste
                notifyDataSetChanged();
                notifyDataSetChanged();
            }
        });
        holder.datetxt.setTag(position);
        // clic sur le reste de la ligne
        holder.datetxt.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                int position = (int)v.getTag();
                // demande de l'affichage du profil dans CalcuActivity au controleur
                ((ListReports)contexte).affichReport(mesRapports.get(position));
            }
        });
        return view;
    }

    private class ViewHolder{
        TextView usernametxt;
        TextView titletxt;
        TextView datetxt;
        ImageView imagereport;
        ImageButton btnListSuppr;
    }
}
