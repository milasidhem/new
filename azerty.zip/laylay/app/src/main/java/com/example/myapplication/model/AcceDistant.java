package com.example.myapplication.model;


import android.util.Log;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.outils.AcceHTTP;
import com.example.myapplication.outils.AsyncResponse;
import com.example.myapplication.outils.MesOutils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Date;
public class AcceDistant implements AsyncResponse {

    // constants
    private static final String SERVERADDER = "http://192.168.1.40/test/serveurtest.php";
    private Controle controle;

    public AcceDistant(){
        controle = Controle.getInstance(null);
    }
    /**
     * retour de serveur distant
     * @param output
     */
    @Override
    public void processFinish(String output) {
        Log.d("SERVEUR", "***********************"+output);
        // decoupage du message recu avec %
        String[] message = output.split("%");
        // dans message[0] : "operation"
        // dans message[1..n] : reste du message
        if (message.length > 1) {
            switch (message[0]) {
                case "enreg":
                    Log.d("enreg", "*********************** " + message[1]);
                    Log.d("note", "*********************** " + message[2]);
                    break;
                case "delr":
                    Log.d("delete from report", "*********************** " + message[1]);
                    //Log.d("delete from image", "*********************** " + message[2]);
                    Log.d("note", "*********************** " + message[2]);
                    break;
                case "delu":
                    Log.d("delete user", "*********************** " + message[1]);
                    Log.d("note", "*********************** " + message[2]);
                    break;
                case "check":
                    Controle.IS_CHECKED = false;
                    Log.d("doing :", "*********************** " + message[1]);
                    Log.d("result : ", "*********************** " + message[2]);
                    Log.d("note : ", "*********************** " + message[3]);
                    if (message[2].trim().equals("checked")) {
                        Controle.IS_CHECKED = true;
                    }
                    break;
                case "registre":
                    Controle.EXISTS = message[2].trim().equals("exists");
                    Log.d("checking :", "*********************** " + message[1]);
                    Log.d("result : ", "*********************** " + message[2]);
                    Log.d("note : ", "*********************** " + message[3]);

                    break;
                case "type":
                    Log.d("les types", "*********************** " + message[1]);
                    Log.d("note", "*********************** " + message[2]);
                    try {
                        // remplir les types
                        JSONArray jSonType = new JSONArray(message[1]);
                        ArrayList<String> lesTypes = new ArrayList<String>();
                        for (int k = 0; k < jSonType.length(); k++) {
                            JSONObject info = new JSONObject(jSonType.get(k).toString());
                            String type = info.getString("nametype");
                            lesTypes.add(type);
                        }
                        controle.setLesTypes(lesTypes);

                    } catch (JSONException e) {
                        Log.d("ERRUER", "conversion JSON impossible" + e.toString());
                    }
                    break;
                case "mine":
                    if (message[1].equals("table is empty")) {
                        Controle.IS_EMPTYM = true;
                    } else {
                        Log.d("mes rapport", "*********************** " + message[1]);
                        Log.d("mes paths d'images", "*********************** " + message[2]);
                        Log.d("note", "*********************** " + message[3]);
                        try {
                            // remplir la list des report du user actual
                            JSONArray jSonInfo = new JSONArray(message[1]);
                            JSONArray jSonImage = new JSONArray(message[2]);
                            ArrayList<Report> mesRapports = new ArrayList<Report>();
                            for (int k = 0; k < jSonInfo.length(); k++) {
                                JSONObject info = new JSONObject(jSonInfo.get(k).toString());
                                JSONObject info2 = new JSONObject(jSonImage.get(k).toString());
                                String username = info.getString("username");
                                String title = info.getString("title");
                                String description = info.getString("description");
                                double locx = info.getDouble("locx");
                                Double locy = info.getDouble("locy");
                                Integer type = info.getInt("type");
                                String image = info2.getString("path");
                                //String image = info.getString("image");
                                Integer etat = info.getInt("etat");
                                String datemesure1 = info.getString("date1");
                                String datemesure2 = info.getString("date2");
                                String datemesure3 = info.getString("date3");
                                Date date1 = MesOutils.convertStringToDate(datemesure1, "yyyy-MM-dd hh:mm:ss");
                                Date date2 = MesOutils.convertStringToDate(datemesure2, "yyyy-MM-dd hh:mm:ss");
                                Date date3 = MesOutils.convertStringToDate(datemesure3, "yyyy-MM-dd hh:mm:ss");
                                String comment = info.getString("comment");
                                String imagecomment = info.getString("imagecomment");
                                Report report = new Report(username, title, description, locx, locy, type, image, etat, date1, date2, date3, comment, imagecomment);
                                mesRapports.add(report);
                            }
                            //controle.mesRapports.clear();
                            controle.setMesRapports(mesRapports);
                        } catch (JSONException e) {
                            Log.d("ERRUER", "conversion JSON impossible" + e.toString());
                        }
                    }
                    break;
                case "tous":
                    if (message[1].equals("table is empty")) {
                        Controle.IS_EMPTY = true;
                        Controle.limit = 0;
                    } else {
                        Controle.IS_EMPTY = false;
                        Log.d("tous les reports", "*********************** " + message[1]);
                        Log.d("note", "*********************** " + message[2]);
                        try {
                            // get all data about all reports
                            JSONArray jSonInfo = new JSONArray(message[1]);
                            //ArrayList<Report> lesRapports = new ArrayList<Report>();
                            for (int k = 0; k < jSonInfo.length(); k++) {
                                JSONObject info = new JSONObject(jSonInfo.get(k).toString());
                                controle.usernames[k] = info.getString("username");
                                controle.lestitle[k] = info.getString("title");
                                controle.desc[k] = info.getString("description");
                                controle.lesx[k] = info.getDouble("locx");
                                Double locy = info.getDouble("locy");
                                controle.lesy[k] = locy;
                                controle.lestypes[k] = info.getInt("type");
                                //String image = info.getString("image");
                                //String datemesure = info.getString("date");
                                //Date date = MesOutils.convertStringToDate(datemesure, "yyyy-MM-dd hh:mm:ss");
                                controle.lesetat[k] = info.getInt("etat");
                            }
                            Controle.limit = jSonInfo.length();
                        } catch (JSONException e) {
                            Log.d("ERRUER", "conversion JSON impossible" + e.toString());
                        }
                    }
                    break;
            }
        }
    }

    public void envoi(String operation, JSONArray lesDonneesJSON){
        AcceHTTP acceDonnes = new AcceHTTP();

        // lien de délégation
        acceDonnes.delegate = this;

        // ajout parametres
        acceDonnes.addParam("operation",operation);
        acceDonnes.addParam("lesdonnees",lesDonneesJSON.toString());

        // appel au seurver
        acceDonnes.execute(SERVERADDER);
    }
}
