package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class Registre extends AppCompatActivity {

    EditText name;
    EditText lastname;
    DatePicker calender;
    EditText adress;
    EditText phone;
    EditText email;
    EditText username;
    EditText password;
    EditText passwordconfirm;
    Controle controle;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registre);
        //Get that instance saved in the previous activity
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        init();
    }


    public void init() {
        name = findViewById(R.id.nametxt);
        lastname = findViewById(R.id.lastnametxt);
        adress = findViewById(R.id.adresstxt);
        phone = findViewById(R.id.phonetxt);
        email = findViewById(R.id.emailtxt);
        username = findViewById(R.id.usernametxt);
        password = findViewById(R.id.passwordtxt);
        passwordconfirm = findViewById(R.id.confirmpasswordtxt);
        calender = findViewById(R.id.dateN);
        this.controle = Controle.getInstance(this);
        controle.mesRapports.clear();
    }


    public void registre(View v){
        if(v==findViewById(R.id.registrebtn)){
            Log.d("message","********************* registre");
            String name = "";
            String lastname = "";
            String dateN = "";
            String adress = "";
            String phone = "";
            String email = "";
            String username = "";
            String password = "";
            String passwordconfirm = "";
            if(!this.name.getText().toString().isEmpty())
                name = this.name.getText().toString();
            //Toast.makeText(this," ff " + name, Toast.LENGTH_LONG).show();
            if(!this.lastname.getText().toString().isEmpty())
                lastname = this.lastname.getText().toString();
            dateN = calender.getDayOfMonth()+"/"+ (calender.getMonth() + 1)+"/"+calender.getYear();
            //Toast.makeText(this," +++++++++++++ " + dateN, Toast.LENGTH_LONG).show();
            if(!this.adress.getText().toString().isEmpty())
                adress = this.adress.getText().toString();
            if(!this.phone.getText().toString().isEmpty())
                phone = this.phone.getText().toString();
            if(!this.email.getText().toString().isEmpty())
                email = this.email.getText().toString();
            if(!this.username.getText().toString().isEmpty())
                username = this.username.getText().toString();
            if(!this.password.getText().toString().isEmpty())
                password = this.password.getText().toString();
            if(!this.passwordconfirm.getText().toString().isEmpty())
                passwordconfirm = this.passwordconfirm.getText().toString();
            if(name.equals("")||lastname.equals("")||dateN.equals("")||adress.equals("")||phone.equals("")||email.equals("")||
            lastname.equals("")||password.equals("")||passwordconfirm.equals("")){
                Toast.makeText(Registre.this,"Saisir Inccorect",Toast.LENGTH_LONG).show();
            }
            else if(!this.password.getText().toString().equals(this.passwordconfirm.getText().toString())){
                Toast.makeText(Registre.this,"Password Inccorect ",Toast.LENGTH_LONG).show();
            }
            else{
                controle.creeUser(name,lastname,dateN,adress,phone,email,username,password);
                int j = 0;
                if(!this.controle.EXISTS) j=1;
                Toast.makeText(this,""+this.controle.EXISTS,Toast.LENGTH_LONG).show();
                if(j==1){
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("username", username);
                    editor.putInt("key", 1);
                    editor.apply();
                    Intent intent = new Intent(this, HomePage.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(this,"change username please",Toast.LENGTH_LONG).show();
            }
        }
    }
}
